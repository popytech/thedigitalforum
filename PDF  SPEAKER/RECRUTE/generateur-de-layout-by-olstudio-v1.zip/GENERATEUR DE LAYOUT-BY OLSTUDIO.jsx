// ========================================
// GÉNÉRATEUR DE CARROUSELS INSTAGRAM
// ========================================
// Script pour Adobe Illustrator
// Génère des layouts à l'intérieur d'une forme sélectionnée

// Vérification qu'un document est ouvert
if (app.documents.length === 0) {
    alert("Veuillez ouvrir un document Illustrator avant d'utiliser ce script.");
} else {
    main();
}

function main() {
    var doc = app.activeDocument;
    
    // ========================================
    // PARAMÈTRES PAR DÉFAUT
    // ========================================
    var settings = {
        nbFormesMin: 8,
        nbFormesMax: 12,
        espacementH: 15,
        espacementV: 15,
        arrondi: 25,
        avecContour: false,
        epaisseurContour: 0,
        margeExterne: 30
    };
    
    var formeSource = null;
    var layoutActuel = null;
    var positionInitiale = null;
    var dimensionsInitiales = null;

    // ========================================
    // CRÉATION DE L'INTERFACE UTILISATEUR
    // ========================================
    var dlg = new Window("dialog", "Générateur de Layout");
    dlg.orientation = "column";
    dlg.alignChildren = ["fill", "top"];
    dlg.spacing = 10;
    dlg.margins = 16;

    // Titre
    var titre = dlg.add("statictext", undefined, "GÉNÉRATEUR DE LAYOUT");
    titre.graphics.font = ScriptUI.newFont(titre.graphics.font.name, "BOLD", 12);

    // Info sélection
    var txtSelection = dlg.add("statictext", undefined, "Sélectionnez une forme sur le plan de travail", {multiline: true});
    txtSelection.characters = 35;
    txtSelection.graphics.foregroundColor = txtSelection.graphics.newPen(txtSelection.graphics.PenType.SOLID_COLOR, [0.8, 0.3, 0.1], 1);

    dlg.add("panel", undefined, undefined, {borderStyle: "black"});

    // Groupe: Marge externe
    var grpMarge = dlg.add("group");
    grpMarge.orientation = "row";
    grpMarge.add("statictext", undefined, "Marge externe (px):");
    var inpMarge = grpMarge.add("edittext", undefined, settings.margeExterne);
    inpMarge.characters = 8;

    // Groupe: Espacement horizontal
    var grpEspaceH = dlg.add("group");
    grpEspaceH.orientation = "row";
    grpEspaceH.add("statictext", undefined, "Espacement H (px):");
    var inpEspaceH = grpEspaceH.add("edittext", undefined, settings.espacementH);
    inpEspaceH.characters = 8;

    // Groupe: Espacement vertical
    var grpEspaceV = dlg.add("group");
    grpEspaceV.orientation = "row";
    grpEspaceV.add("statictext", undefined, "Espacement V (px):");
    var inpEspaceV = grpEspaceV.add("edittext", undefined, settings.espacementV);
    inpEspaceV.characters = 8;

    // Groupe: Arrondi des angles
    var grpArrondi = dlg.add("group");
    grpArrondi.orientation = "row";
    grpArrondi.add("statictext", undefined, "Arrondi angles (px):");
    var inpArrondi = grpArrondi.add("edittext", undefined, settings.arrondi);
    inpArrondi.characters = 8;

    dlg.add("panel", undefined, undefined, {borderStyle: "black"});

    // Groupe: Nombre de formes
    var grpNombre = dlg.add("group");
    grpNombre.orientation = "row";
    grpNombre.add("statictext", undefined, "Formes (min-max):");
    var inpMin = grpNombre.add("edittext", undefined, settings.nbFormesMin);
    inpMin.characters = 4;
    grpNombre.add("statictext", undefined, "-");
    var inpMax = grpNombre.add("edittext", undefined, settings.nbFormesMax);
    inpMax.characters = 4;
    
    var txtNote = dlg.add("statictext", undefined, "Note: Le layout remplira tout l'espace", {multiline: true});
    txtNote.characters = 35;
    txtNote.graphics.font = ScriptUI.newFont(txtNote.graphics.font.name, "REGULAR", 9);

    // Options
    var chkContour = dlg.add("checkbox", undefined, "Ajouter un contour blanc");
    chkContour.value = settings.avecContour;

    // Groupe: Épaisseur contour
    var grpEpaisseur = dlg.add("group");
    grpEpaisseur.orientation = "row";
    grpEpaisseur.add("statictext", undefined, "Épaisseur contour:");
    var inpEpaisseur = grpEpaisseur.add("edittext", undefined, settings.epaisseurContour);
    inpEpaisseur.characters = 5;

    dlg.add("panel", undefined, undefined, {borderStyle: "black"});

    // Info
    var txtInfo = dlg.add("statictext", undefined, "Prêt à générer...", {multiline: true});
    txtInfo.characters = 35;

    // Boutons d'action principaux
    var grpBoutons = dlg.add("group");
    grpBoutons.orientation = "row";
    grpBoutons.alignment = ["fill", "top"];
    
    var btnGenerer = grpBoutons.add("button", undefined, "GÉNÉRER LAYOUT");
    btnGenerer.preferredSize.width = 140;
    btnGenerer.preferredSize.height = 40;
    
    var btnReorganiser = grpBoutons.add("button", undefined, "Réorganiser");
    btnReorganiser.preferredSize.height = 40;
    btnReorganiser.enabled = false;
    
    // Boutons secondaires
    var grpBoutons2 = dlg.add("group");
    grpBoutons2.orientation = "row";
    grpBoutons2.alignment = ["fill", "top"];
    
    var btnAleatoire = grpBoutons2.add("button", undefined, "Aléatoire");
    btnAleatoire.preferredSize.height = 35;
    btnAleatoire.enabled = false;
    
    var btnDegrouper = grpBoutons2.add("button", undefined, "Dégrouper");
    btnDegrouper.preferredSize.height = 35;
    btnDegrouper.enabled = false;
    
    var btnEffacer = grpBoutons2.add("button", undefined, "Effacer layout");
    btnEffacer.enabled = false;
    
    var btnFermer = grpBoutons2.add("button", undefined, "Fermer", {name: "cancel"});

    // ========================================
    // SIGNATURE
    // ========================================
    dlg.add("panel", undefined, undefined, {borderStyle: "black"});
    
    var grpSignature = dlg.add("group");
    grpSignature.orientation = "column";
    grpSignature.alignChildren = ["center", "top"];
    grpSignature.spacing = 2;
    
    var txtCopyright = grpSignature.add("statictext", undefined, "© 2025 OL STUDIO");
    txtCopyright.graphics.font = ScriptUI.newFont(txtCopyright.graphics.font.name, "REGULAR", 8);
    txtCopyright.graphics.foregroundColor = txtCopyright.graphics.newPen(txtCopyright.graphics.PenType.SOLID_COLOR, [0.5, 0.5, 0.5], 1);
    
    var txtVersion = grpSignature.add("statictext", undefined, "Générateur de Layout v1.0");
    txtVersion.graphics.font = ScriptUI.newFont(txtVersion.graphics.font.name, "REGULAR", 7);
    txtVersion.graphics.foregroundColor = txtVersion.graphics.newPen(txtVersion.graphics.PenType.SOLID_COLOR, [0.6, 0.6, 0.6], 1);

    // ========================================
    // TYPES DE FORMES
    // ========================================
    var TypeForme = {
        CARRE: 1,
        RECT_H: 2,
        RECT_V: 3,
        GRAND_H: 4,
        GRAND_CARRE: 5
    };

    // ========================================
    // FONCTIONS DE GRILLE
    // ========================================
    
    function creerGrille(nbColonnes, nbLignes) {
        var grille = [];
        for (var i = 0; i < nbLignes; i++) {
            grille[i] = [];
            for (var j = 0; j < nbColonnes; j++) {
                grille[i][j] = 0;
            }
        }
        return grille;
    }
    
    function peutPlacerForme(grille, ligne, col, largeur, hauteur) {
        if (ligne + hauteur > grille.length || col + largeur > grille[0].length) {
            return false;
        }
        
        for (var i = ligne; i < ligne + hauteur; i++) {
            for (var j = col; j < col + largeur; j++) {
                if (grille[i][j] !== 0) {
                    return false;
                }
            }
        }
        return true;
    }
    
    function placerForme(grille, ligne, col, largeur, hauteur, id) {
        for (var i = ligne; i < ligne + hauteur; i++) {
            for (var j = col; j < col + largeur; j++) {
                grille[i][j] = id;
            }
        }
    }

    function determinerGrilleOptimale(largeurZone, hauteurZone, espH, espV) {
        var ratioZone = largeurZone / hauteurZone;
        
        var nbColonnes, nbLignes;
        
        if (ratioZone > 1.5) {
            nbColonnes = 5;
            nbLignes = 3;
        } else if (ratioZone > 1.2) {
            nbColonnes = 4;
            nbLignes = 3;
        } else if (ratioZone < 0.65) {
            nbColonnes = 2;
            nbLignes = 5;
        } else if (ratioZone < 0.85) {
            nbColonnes = 3;
            nbLignes = 4;
        } else {
            nbColonnes = 3;
            nbLignes = 3;
        }
        
        // Calculer pour REMPLIR 100% de la largeur
        var largeurCellule = (largeurZone - (nbColonnes - 1) * espH) / nbColonnes;
        
        // Calculer pour REMPLIR 100% de la hauteur
        var hauteurCellule = (hauteurZone - (nbLignes - 1) * espV) / nbLignes;
        
        // IMPORTANT: Ne pas prendre le min, mais calculer les deux dimensions séparément
        // pour que le layout remplisse 100% dans les deux directions
        
        return {
            nbColonnes: nbColonnes,
            nbLignes: nbLignes,
            largeurCellule: largeurCellule,  // Largeur pour remplir horizontalement
            hauteurCellule: hauteurCellule,  // Hauteur pour remplir verticalement
            largeurReelle: largeurZone,      // Utilise 100% de la largeur
            hauteurReelle: hauteurZone       // Utilise 100% de la hauteur
        };
    }

    function genererLayoutAleatoire(nbColonnes, nbLignes, ratioZone, nbFormesMin, nbFormesMax) {
        var grille = creerGrille(nbColonnes, nbLignes);
        var formes = [];
        
        var nbFormes = nbFormesMin + Math.floor(Math.random() * (nbFormesMax - nbFormesMin + 1));
        var formesGenerees = 0;
        var tentatives = 0;
        var maxTentatives = 3000;
        
        var typesDisponibles = [];
        
        if (ratioZone > 1.3) {
            typesDisponibles = [
                TypeForme.RECT_H, TypeForme.RECT_H, TypeForme.RECT_H, TypeForme.RECT_H,
                TypeForme.RECT_V, TypeForme.RECT_V, TypeForme.RECT_V,
                TypeForme.GRAND_H, TypeForme.GRAND_H,
                TypeForme.CARRE, TypeForme.CARRE, TypeForme.CARRE,
                TypeForme.GRAND_CARRE, TypeForme.GRAND_CARRE
            ];
        } else if (ratioZone < 0.75) {
            typesDisponibles = [
                TypeForme.RECT_V, TypeForme.RECT_V, TypeForme.RECT_V, TypeForme.RECT_V, TypeForme.RECT_V,
                TypeForme.RECT_H, TypeForme.RECT_H,
                TypeForme.CARRE, TypeForme.CARRE, TypeForme.CARRE,
                TypeForme.GRAND_CARRE, TypeForme.GRAND_CARRE
            ];
        } else {
            typesDisponibles = [
                TypeForme.CARRE, TypeForme.CARRE, TypeForme.CARRE, TypeForme.CARRE,
                TypeForme.RECT_H, TypeForme.RECT_H, TypeForme.RECT_H,
                TypeForme.RECT_V, TypeForme.RECT_V, TypeForme.RECT_V, TypeForme.RECT_V,
                TypeForme.GRAND_CARRE, TypeForme.GRAND_CARRE,
                TypeForme.GRAND_H, TypeForme.GRAND_H
            ];
        }
        
        while (formesGenerees < nbFormes && tentatives < maxTentatives) {
            tentatives++;
            
            var typeForme = typesDisponibles[Math.floor(Math.random() * typesDisponibles.length)];
            var largeur = 1;
            var hauteur = 1;
            
            switch(typeForme) {
                case TypeForme.CARRE:
                    largeur = 1;
                    hauteur = 1;
                    break;
                case TypeForme.RECT_H:
                    largeur = 2;
                    hauteur = 1;
                    break;
                case TypeForme.RECT_V:
                    largeur = 1;
                    hauteur = 2;
                    break;
                case TypeForme.GRAND_H:
                    largeur = Math.min(3, nbColonnes);
                    hauteur = 1;
                    break;
                case TypeForme.GRAND_CARRE:
                    largeur = 2;
                    hauteur = 2;
                    break;
            }
            
            var positionTrouvee = false;
            for (var ligne = 0; ligne < nbLignes && !positionTrouvee; ligne++) {
                for (var col = 0; col < nbColonnes && !positionTrouvee; col++) {
                    if (peutPlacerForme(grille, ligne, col, largeur, hauteur)) {
                        formesGenerees++;
                        placerForme(grille, ligne, col, largeur, hauteur, formesGenerees);
                        
                        formes.push({
                            id: formesGenerees,
                            type: typeForme,
                            ligne: ligne,
                            col: col,
                            largeur: largeur,
                            hauteur: hauteur
                        });
                        
                        positionTrouvee = true;
                    }
                }
            }
        }
        
        // PHASE 2: REMPLIR espaces vides
        tentatives = 0;
        var continuerRemplissage = true;
        
        while (continuerRemplissage && tentatives < 1000) {
            tentatives++;
            continuerRemplissage = false;
            
            for (var ligne = 0; ligne < nbLignes; ligne++) {
                for (var col = 0; col < nbColonnes; col++) {
                    if (grille[ligne][col] === 0) {
                        var formesTentatives = [
                            {l: 2, h: 2, type: TypeForme.GRAND_CARRE},
                            {l: 2, h: 1, type: TypeForme.RECT_H},
                            {l: 1, h: 2, type: TypeForme.RECT_V},
                            {l: 1, h: 1, type: TypeForme.CARRE}
                        ];
                        
                        for (var t = 0; t < formesTentatives.length; t++) {
                            var tentativeForme = formesTentatives[t];
                            if (peutPlacerForme(grille, ligne, col, tentativeForme.l, tentativeForme.h)) {
                                formesGenerees++;
                                placerForme(grille, ligne, col, tentativeForme.l, tentativeForme.h, formesGenerees);
                                
                                formes.push({
                                    id: formesGenerees,
                                    type: tentativeForme.type,
                                    ligne: ligne,
                                    col: col,
                                    largeur: tentativeForme.l,
                                    hauteur: tentativeForme.h
                                });
                                
                                continuerRemplissage = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        return formes;
    }

    // ========================================
    // FONCTIONS DE DESSIN
    // ========================================
    
    function creerRectangleArrondi(x, y, largeur, hauteur, rayon) {
        // Créer le rectangle avec les coordonnées standard Illustrator
        // top, left, width, height
        var rect = doc.pathItems.roundedRectangle(
            y,           // top (coordonnée Y)
            x,           // left (coordonnée X)
            largeur,     // width
            hauteur,     // height
            rayon,       // horizontal radius
            rayon        // vertical radius
        );
        return rect;
    }
    
    function dessinerLayout(formes, posX, posY, largeurCell, hauteurCell, espacementH, espacementV, arrondi) {
        var groupe = doc.groupItems.add();
        groupe.name = "Layout_" + new Date().getTime();
        
        for (var i = 0; i < formes.length; i++) {
            var forme = formes[i];
            
            // Utiliser des dimensions différentes pour largeur et hauteur
            var x = posX + (forme.col * (largeurCell + espacementH));
            var y = posY - (forme.ligne * (hauteurCell + espacementV));
            var w = (forme.largeur * largeurCell) + ((forme.largeur - 1) * espacementH);
            var h = (forme.hauteur * hauteurCell) + ((forme.hauteur - 1) * espacementV);
            
            var rect = creerRectangleArrondi(x, y, w, h, arrondi);
            
            // Nommer chaque forme pour faciliter l'identification
            rect.name = "Forme_" + (i + 1);
            
            var couleur = new RGBColor();
            couleur.red = 0;
            couleur.green = 0;
            couleur.blue = 0;
            
            rect.filled = true;
            rect.fillColor = couleur;
            
            if (settings.avecContour) {
                rect.stroked = true;
                var couleurContour = new RGBColor();
                couleurContour.red = 255;
                couleurContour.green = 255;
                couleurContour.blue = 255;
                rect.strokeColor = couleurContour;
                rect.strokeWidth = settings.epaisseurContour;
            } else {
                rect.stroked = false;
            }
            
            rect.moveToBeginning(groupe);
        }
        
        return groupe;
    }

    // ========================================
    // FONCTIONS PRINCIPALES
    // ========================================
    
    function mettreAJourSettings() {
        settings.margeExterne = parseFloat(inpMarge.text) || 30;
        settings.espacementH = parseFloat(inpEspaceH.text) || 15;
        settings.espacementV = parseFloat(inpEspaceV.text) || 15;
        settings.arrondi = parseFloat(inpArrondi.text) || 25;
        settings.nbFormesMin = parseInt(inpMin.text) || 8;
        settings.nbFormesMax = parseInt(inpMax.text) || 12;
        settings.avecContour = chkContour.value;
        settings.epaisseurContour = parseFloat(inpEpaisseur.text) || 0;
        
        if (settings.nbFormesMin > settings.nbFormesMax) {
            var temp = settings.nbFormesMin;
            settings.nbFormesMin = settings.nbFormesMax;
            settings.nbFormesMax = temp;
        }
    }
    
    function verifierSelection() {
        if (doc.selection.length === 0) {
            alert("Veuillez sélectionner une forme (rectangle, carré, cercle, etc.) sur laquelle appliquer le layout.");
            return false;
        }
        
        formeSource = doc.selection[0];
        
        if (!formeSource.typename || 
            (formeSource.typename !== "PathItem" && 
             formeSource.typename !== "CompoundPathItem" &&
             formeSource.typename !== "GroupItem")) {
            alert("Veuillez sélectionner une forme graphique valide (rectangle, carré, etc.).");
            return false;
        }
        
        return true;
    }
    
    function genererLayout() {
        try {
            mettreAJourSettings();
            
            if (!verifierSelection()) {
                return;
            }
            
            var bounds = formeSource.geometricBounds;
            var largeurForme = bounds[2] - bounds[0];
            var hauteurForme = bounds[1] - bounds[3];
            
            positionInitiale = {
                left: bounds[0],
                top: bounds[1],
                right: bounds[2],
                bottom: bounds[3]
            };
            
            dimensionsInitiales = {
                largeur: largeurForme,
                hauteur: hauteurForme
            };
            
            if (layoutActuel !== null) {
                try {
                    layoutActuel.remove();
                } catch(e) {}
            }
            
            var largeurZone = largeurForme - (2 * settings.margeExterne);
            var hauteurZone = hauteurForme - (2 * settings.margeExterne);
            
            var grilleOptimale = determinerGrilleOptimale(largeurZone, hauteurZone, settings.espacementH, settings.espacementV);
            
            var nbColonnes = grilleOptimale.nbColonnes;
            var nbLignes = grilleOptimale.nbLignes;
            var largeurCell = grilleOptimale.largeurCellule;
            var hauteurCell = grilleOptimale.hauteurCellule;
            var ratioZone = largeurZone / hauteurZone;
            
            // Pas de centrage - le layout remplit 100% de l'espace
            var formesLayout = genererLayoutAleatoire(nbColonnes, nbLignes, ratioZone, settings.nbFormesMin, settings.nbFormesMax);
            
            // Position de départ = juste la marge externe
            var posX = positionInitiale.left + settings.margeExterne;
            var posY = positionInitiale.top - settings.margeExterne;
            
            layoutActuel = dessinerLayout(formesLayout, posX, posY, largeurCell, hauteurCell, settings.espacementH, settings.espacementV, settings.arrondi);
            
            formeSource.hidden = true;
            
            var formatTexte = ratioZone > 1.2 ? "paysage" : ratioZone < 0.85 ? "portrait" : "carré";
            txtInfo.text = "Forme transformée en layout " + formatTexte + " !\n" + formesLayout.length + " formes créées";
            txtSelection.text = "Dimensions: " + Math.round(largeurForme) + "×" + Math.round(hauteurForme) + " px";
            
            btnReorganiser.enabled = true;
            btnAleatoire.enabled = true;
            btnDegrouper.enabled = true;
            btnEffacer.enabled = true;
            
            app.redraw();
        } catch (e) {
            alert("Erreur lors de la génération: " + e.message + "\nLigne: " + e.line);
        }
    }
    
    function reorganiserLayout() {
        if (layoutActuel === null || positionInitiale === null) return;
        
        try {
            mettreAJourSettings();
            
            // Supprimer l'ancien layout
            layoutActuel.remove();
            
            // Utiliser les dimensions et positions sauvegardées
            var largeurForme = dimensionsInitiales.largeur;
            var hauteurForme = dimensionsInitiales.hauteur;
            var largeurZone = largeurForme - (2 * settings.margeExterne);
            var hauteurZone = hauteurForme - (2 * settings.margeExterne);
            
            var grilleOptimale = determinerGrilleOptimale(largeurZone, hauteurZone, settings.espacementH, settings.espacementV);
            
            var nbColonnes = grilleOptimale.nbColonnes;
            var nbLignes = grilleOptimale.nbLignes;
            var largeurCell = grilleOptimale.largeurCellule;
            var hauteurCell = grilleOptimale.hauteurCellule;
            var ratioZone = largeurZone / hauteurZone;
            
            var formesLayout = genererLayoutAleatoire(nbColonnes, nbLignes, ratioZone, settings.nbFormesMin, settings.nbFormesMax);
            
            // Utiliser EXACTEMENT la position sauvegardée
            var posX = positionInitiale.left + settings.margeExterne;
            var posY = positionInitiale.top - settings.margeExterne;
            
            layoutActuel = dessinerLayout(formesLayout, posX, posY, largeurCell, hauteurCell, settings.espacementH, settings.espacementV, settings.arrondi);
            
            txtInfo.text = "Layout réorganisé !\n" + formesLayout.length + " formes créées";
            app.redraw();
        } catch (e) {
            alert("Erreur lors de la réorganisation: " + e.message);
        }
    }
    
    function genererAleatoire() {
        if (layoutActuel === null || positionInitiale === null) return;
        
        try {
            // Supprimer l'ancien layout
            layoutActuel.remove();
            
            // Changer ALÉATOIREMENT les paramètres
            settings.espacementH = 10 + Math.floor(Math.random() * 25);
            settings.espacementV = 10 + Math.floor(Math.random() * 25);
            settings.arrondi = 15 + Math.floor(Math.random() * 40);
            settings.margeExterne = 20 + Math.floor(Math.random() * 40);
            settings.nbFormesMin = 6 + Math.floor(Math.random() * 4);
            settings.nbFormesMax = settings.nbFormesMin + 3 + Math.floor(Math.random() * 5);
            
            // Mettre à jour les champs d'interface
            inpMarge.text = settings.margeExterne;
            inpEspaceH.text = settings.espacementH;
            inpEspaceV.text = settings.espacementV;
            inpArrondi.text = settings.arrondi;
            inpMin.text = settings.nbFormesMin;
            inpMax.text = settings.nbFormesMax;
            
            // Utiliser les dimensions et positions sauvegardées
            var largeurForme = dimensionsInitiales.largeur;
            var hauteurForme = dimensionsInitiales.hauteur;
            var largeurZone = largeurForme - (2 * settings.margeExterne);
            var hauteurZone = hauteurForme - (2 * settings.margeExterne);
            
            var grilleOptimale = determinerGrilleOptimale(largeurZone, hauteurZone, settings.espacementH, settings.espacementV);
            
            var nbColonnes = grilleOptimale.nbColonnes;
            var nbLignes = grilleOptimale.nbLignes;
            var largeurCell = grilleOptimale.largeurCellule;
            var hauteurCell = grilleOptimale.hauteurCellule;
            var ratioZone = largeurZone / hauteurZone;
            
            var formesLayout = genererLayoutAleatoire(nbColonnes, nbLignes, ratioZone, settings.nbFormesMin, settings.nbFormesMax);
            
            // Utiliser EXACTEMENT la position sauvegardée
            var posX = positionInitiale.left + settings.margeExterne;
            var posY = positionInitiale.top - settings.margeExterne;
            
            layoutActuel = dessinerLayout(formesLayout, posX, posY, largeurCell, hauteurCell, settings.espacementH, settings.espacementV, settings.arrondi);
            
            txtInfo.text = "Layout aléatoire généré !\nParamètres randomisés";
            app.redraw();
        } catch (e) {
            alert("Erreur lors de la génération aléatoire: " + e.message);
        }
    }
    
    function degrouperLayout() {
        if (layoutActuel === null) return;
        
        try {
            // Récupérer tous les éléments du groupe
            var elements = [];
            for (var i = 0; i < layoutActuel.pageItems.length; i++) {
                elements.push(layoutActuel.pageItems[i]);
            }
            
            // Déplacer chaque élément hors du groupe vers le calque principal
            for (var i = elements.length - 1; i >= 0; i--) {
                elements[i].move(doc.activeLayer, ElementPlacement.PLACEATEND);
            }
            
            // Supprimer le groupe vide
            layoutActuel.remove();
            layoutActuel = null;
            
            // Sélectionner toutes les formes dégroupées
            doc.selection = elements;
            
            txtInfo.text = "Layout dégroupé !\n" + elements.length + " formes séparées\nPrêt pour export PSD";
            
            // Désactiver les boutons qui nécessitent le groupe
            btnReorganiser.enabled = false;
            btnAleatoire.enabled = false;
            btnDegrouper.enabled = false;
            
            app.redraw();
            
            // Afficher les instructions
            alert("Layout dégroupé avec succès !\n\n" +
                  "Pour exporter vers Photoshop :\n" +
                  "1. Fichier > Exporter > Exporter sous...\n" +
                  "2. Choisir format : Photoshop (PSD)\n" +
                  "3. Options : Cocher 'Écrire les calques'\n" +
                  "4. Chaque forme sera un calque séparé dans Photoshop !\n\n" +
                  "Les formes sont nommées : Forme_1, Forme_2, etc.");
            
        } catch (e) {
            alert("Erreur lors du dégroupement: " + e.message);
        }
    }
    
    function effacerLayout() {
        if (layoutActuel !== null) {
            try {
                layoutActuel.remove();
                layoutActuel = null;
                
                if (formeSource && formeSource.hidden) {
                    formeSource.hidden = false;
                }
                
                positionInitiale = null;
                dimensionsInitiales = null;
                
                txtInfo.text = "Layout effacé. Forme originale restaurée.";
                txtSelection.text = "Sélectionnez une nouvelle forme";
                btnReorganiser.enabled = false;
                btnAleatoire.enabled = false;
                btnDegrouper.enabled = false;
                btnEffacer.enabled = false;
                app.redraw();
            } catch(e) {
                alert("Erreur lors de l'effacement: " + e.message);
            }
        }
    }

    // ========================================
    // ÉVÉNEMENTS
    // ========================================
    
    btnGenerer.onClick = function() {
        genererLayout();
    };

    btnReorganiser.onClick = function() {
        reorganiserLayout();
    };
    
    btnAleatoire.onClick = function() {
        genererAleatoire();
    };
    
    btnDegrouper.onClick = function() {
        degrouperLayout();
    };

    btnEffacer.onClick = function() {
        effacerLayout();
    };

    // ========================================
    // AFFICHAGE DE LA FENÊTRE
    // ========================================
    dlg.center();
    dlg.show();
}